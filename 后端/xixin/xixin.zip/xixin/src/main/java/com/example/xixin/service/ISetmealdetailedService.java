package com.example.xixin.service;

import com.example.xixin.entity.Setmealdetailed;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author moki
 * @since 2024-06-13
 */
public interface ISetmealdetailedService extends IService<Setmealdetailed> {

}
