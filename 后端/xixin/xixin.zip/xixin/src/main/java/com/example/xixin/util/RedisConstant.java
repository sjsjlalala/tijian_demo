package com.example.xixin.util;

/**
 * @projectName: xixin
 * @package: com.example.xixin.util
 * @className: RedisConstant
 * @author: moki
 * @description: TODO
 * @date: 2024/6/13 12:32
 * @version: 1.0
 */
public class RedisConstant {
    public static final String SETMEAL_PIC_RESOURCES = "setmealPicResources";

}
