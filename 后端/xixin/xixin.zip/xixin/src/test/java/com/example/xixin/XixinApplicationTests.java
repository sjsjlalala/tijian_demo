package com.example.xixin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XixinApplicationTests {

    @Test
    void contextLoads() {
    }

}
